package com.sharad.recepemgmt;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.sharad.recepemgmt.controller.RmsControllerTest;
import com.sharad.recepemgmt.controller.TestRmsController;
import com.sharad.recepemgmt.junitTest.RmsJPAJunitTest;

@RunWith(SpringRunner.class)
@SpringBootTest
class RecepeManagementSystemApplicationTests {
	
	@Autowired
	RmsJPAJunitTest jpaJunitTest;
	@Autowired
	RmsControllerTest rmsControllerTest;
	@Autowired
	TestRmsController testRmsController;
}
