package com.sharad.recepemgmt.exceptions;

/**
 * This class is user defined InvalidRecepeIDException class
 * @author SHARAD
 *
 */

public class InvalidRecepeIDException extends RuntimeException{


	private static final long serialVersionUID = 1L;

	/**
	 * @author SHARAD
	 * @param message
	 * @param cause
	 */
	public InvalidRecepeIDException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * @author SHARAD
	 * @param message
	 */
	public InvalidRecepeIDException(String message) {
		super(message);
	}
	

	/**
	 * @author SHARAD
	 * @param cause
	 */
	public InvalidRecepeIDException(Throwable cause) {
		super(cause);
	}

}
