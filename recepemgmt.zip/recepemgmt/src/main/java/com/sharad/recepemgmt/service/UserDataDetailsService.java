package com.sharad.recepemgmt.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.sharad.recepemgmt.bean.UserDataDO;
import com.sharad.recepemgmt.dao.UamUserRepository;
/**
 * UserDataDetailsService is used to get Data from repository
 * @author SHARAD
 *
 */
public class UserDataDetailsService implements UserDetailsService{

	@Autowired
	private UamUserRepository uamUserRepository;
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		UserDataDO userdo  = uamUserRepository.findByUsername(username);
		
		if(null == userdo) {
			throw  new UsernameNotFoundException("User:"+username+" doesn't exists");
		}		
		return new UserDataDetails(userdo);
	}

}
