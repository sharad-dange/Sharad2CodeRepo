package com.sharad.recepemgmt.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.sharad.recepemgmt.bean.RecepesMgmtResponseBean;
import com.sharad.recepemgmt.constants.RmsConstants;
import com.sharad.recepemgmt.exceptions.InvalidRecepeIDException;
import com.sharad.recepemgmt.exceptions.RecepeNotFoundException;

/**
 * This Class is used to handle Global Exceptions
 * @author SHARAD
 *
 */

@RestControllerAdvice
public class RecepeMgmtExceptionHandler {
	
	/**
	 * This method used to handle custome Exception named as RecepeNotFoundException
	 * @author SHARAD
	 * @param e
	 * @return
	 */
	
	@ExceptionHandler
	public ResponseEntity<RecepesMgmtResponseBean> handleException(RecepeNotFoundException e){

		RecepesMgmtResponseBean recepesMgmtResponseBean =  new RecepesMgmtResponseBean();
		recepesMgmtResponseBean.setResponseStatus(RmsConstants.RMS_RESPONSE_CODE_1001);
		recepesMgmtResponseBean.setResponseDesc(RmsConstants.RMS_ERROR+RmsConstants.RMS_COLUN+RmsConstants.RMS_RECEPE_NOT_FOUND_1001);
		return new ResponseEntity<>(recepesMgmtResponseBean, HttpStatus.NOT_FOUND);		
	}
	
	/**
	 * This method is used to handle custom Exception named as InvalidRecepeIDException
	 * @author SHARAD
	 * @param e
	 * @return
	 */
	@ExceptionHandler
	public ResponseEntity<RecepesMgmtResponseBean> handleException(InvalidRecepeIDException e){

		RecepesMgmtResponseBean recepesMgmtResponseBean =  new RecepesMgmtResponseBean();
		recepesMgmtResponseBean.setResponseStatus(RmsConstants.RMS_RESPONSE_CODE_1003);
		recepesMgmtResponseBean.setResponseDesc(RmsConstants.RMS_ERROR+RmsConstants.RMS_COLUN+RmsConstants.ERR_INVALID_RECEPE_ID);
		return new ResponseEntity<>(recepesMgmtResponseBean, HttpStatus.BAD_REQUEST);		
	}

	/**
	 * This method used to handle Exception 
	 * @author SHARAD
	 * @param e
	 * @return
	 */
	@ExceptionHandler
	public ResponseEntity<RecepesMgmtResponseBean> handleException(Exception e){

		RecepesMgmtResponseBean recepesMgmtResponseBean =  new RecepesMgmtResponseBean();
		recepesMgmtResponseBean.setResponseStatus(RmsConstants.RMS_RESPONSE_CODE_1002);
		recepesMgmtResponseBean.setResponseDesc(e.getMessage());
		return new ResponseEntity<>(recepesMgmtResponseBean, HttpStatus.BAD_REQUEST);		
	}

}
