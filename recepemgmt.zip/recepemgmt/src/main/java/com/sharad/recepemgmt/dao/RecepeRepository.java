package com.sharad.recepemgmt.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import com.sharad.recepemgmt.bean.Recepes;
/**
 * This is the RecepeRepository which is responsible for
 * getting databases values from RECPE_DETAILS and RECEPE_INGREDIENTS
 * using JPA repository
 * @author SHARAD
 *
 */
public interface RecepeRepository extends JpaRepository<Recepes, Integer>
{	

}
