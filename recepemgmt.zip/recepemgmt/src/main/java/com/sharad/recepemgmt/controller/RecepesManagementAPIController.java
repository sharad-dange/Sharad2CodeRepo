package com.sharad.recepemgmt.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.sharad.recepemgmt.processhelper.RecepesMgmtProcessAPIHelper;
import com.sharad.recepemgmt.bean.Recepes;
import com.sharad.recepemgmt.bean.RecepesMgmtRequestBean;
import com.sharad.recepemgmt.bean.RecepesMgmtResponseBean;
import com.sharad.recepemgmt.constants.RmsConstants;
import com.sharad.recepemgmt.exceptions.InvalidRecepeIDException;
import com.sharad.recepemgmt.exceptions.InvalidRequestBodyException;
/**
 * This is the rest controller class, which is responsible for Request handling 
 * @author SHARAD
 *
 */

@RestController
@RequestMapping("/restapi")
public class RecepesManagementAPIController {

	private static final Logger logger = LogManager.getLogger(RecepesManagementAPIController.class);
	
	@Autowired
	RecepesMgmtProcessAPIHelper recepesMgmtProcessAPIHelper;

	/**
	 * This GetMapping Action "/recepes" used to return list of recepes
	 * @author SHARAD
	 * @return
	 */
	
	@GetMapping("/recepes")
	@ResponseBody
	public RecepesMgmtResponseBean getAllRecepes() {
		if(logger.isInfoEnabled())
			logger.info("Entered into getAllRecepes() method, Starting the operation now.");

		RecepesMgmtResponseBean response = new RecepesMgmtResponseBean();
		response = recepesMgmtProcessAPIHelper.getAllRecepes();
				
		if(logger.isInfoEnabled())
			logger.info("Exited from getAllRecepes() method");

		return response;
	}

	/**
	 * This GetMapping Action "/recepes/{id}" used to return list of recepes based on recepe id
	 * @author SHARAD
	 * @param recepeId
	 * @return
	 */

	@GetMapping("/recepes/{recepeId}")
	@ResponseBody
	public RecepesMgmtResponseBean getRecepeByID(@PathVariable int recepeId) {
		
		if(logger.isInfoEnabled())
			logger.info("Entered into getRecepeByID() method, Starting the operation now. Request Data >> RECEPE_ID :"+recepeId);
		
		if(0>recepeId) {
			logger.error("getRecepeByID(): Invalid recepeId : "+recepeId);
			throw new InvalidRecepeIDException(RmsConstants.ERR_INVALID_RECEPE_ID);
		}
		
		RecepesMgmtResponseBean response = new RecepesMgmtResponseBean();
		response = recepesMgmtProcessAPIHelper.getRecepeFromID(recepeId);
		
		if(logger.isInfoEnabled())
			logger.info("Exited from getRecepeByID() method");
		
		return response;
	}

	/**
	 * This addRecepe() is used to create new recepe details using Recepe Request body
	 * @author SHARAD
	 * @param recepesreq
	 * @return
	 */
	@PostMapping("/recepes")
	@ResponseBody
	public RecepesMgmtResponseBean addRecepe(@RequestBody Recepes recepesreq) {		
		
		if(logger.isInfoEnabled())
			logger.info("Entered into addRecepe() method, Starting the operation now");
		
		if(null == recepesreq) {
			logger.error("addRecepe(): Invalid Request Body observed");
			throw new InvalidRequestBodyException(RmsConstants.ERR_INVALID_RECEPE_ID);
		}
		
		RecepesMgmtResponseBean response = new RecepesMgmtResponseBean();
		response = recepesMgmtProcessAPIHelper.createRecepe(recepesreq);
		
		if(logger.isInfoEnabled())
			logger.info("Exited from addRecepe() method");
		
		return response;
	}

	/**
	 * This updateRecepe() used to updated recepe using recepe id and Recepe request body
	 * @author SHARAD
	 * @param recepeId
	 * @param recepesreq
	 * @return
	 */
	@PutMapping("/recepes/{recepeId}")
	@ResponseBody
	public RecepesMgmtResponseBean updateRecepe(@PathVariable int recepeId,@RequestBody Recepes recepesreq) {	
		if(logger.isInfoEnabled())
			logger.info("Entered into addRecepe() method, Starting the operation now");
		
		if(null == recepesreq) {
			logger.error("updateRecepe(): Invalid Request Body observed");
			throw new InvalidRequestBodyException(RmsConstants.ERR_INVALID_REQUEST_BODY);
		}
		
		RecepesMgmtResponseBean response = new RecepesMgmtResponseBean();
		response = recepesMgmtProcessAPIHelper.updateRecepe(recepeId,recepesreq);
		
		if(logger.isInfoEnabled())
			logger.info("Exited from updateRecepe() method");
		return response;
	}

	/**
	 * This deleteEmployee() used for delete the recepe based on request recepe id
	 * @author SHARAD
	 * @param recepeId
	 * @return
	 */
	@DeleteMapping("/recepes/{recepeId}")
	@ResponseBody
	public RecepesMgmtResponseBean deleteEmployee(@PathVariable int recepeId) {
		
		if(logger.isInfoEnabled())
			logger.info("Entered into deleteEmployee() method, Starting the operation now. Request Data >> RECEPE_ID :"+recepeId);
		
		if(0>recepeId) {
			logger.error("deleteEmployee(): Invalid recepeId : "+recepeId);
			throw new InvalidRecepeIDException(RmsConstants.ERR_INVALID_RECEPE_ID);
		}
		
		RecepesMgmtResponseBean response = new RecepesMgmtResponseBean();
		response = recepesMgmtProcessAPIHelper.deleteRecepeByID(recepeId);
		
		if(logger.isInfoEnabled())
			logger.info("Exited from deleteEmployee() method");
		
		return response;
	}

}
