package com.sharad.recepemgmt.bean;

import java.util.List;


/**
 * This is  the Response body bean used to map response data
 * @author SHARAD
 *
 */

public class RecepesMgmtResponseBean {
	
	private String responseStatus;
	private String responseDesc;
	
	private List<Recepes> recepeList;
	
	
	
	
	public List<Recepes> getRecepeList() {
		return recepeList;
	}


	public void setRecepeList(List<Recepes> recepeList) {
		this.recepeList = recepeList;
	}


	public RecepesMgmtResponseBean() {
	}


	public String getResponseStatus() {
		return responseStatus;
	}


	public void setResponseStatus(String responseStatus) {
		this.responseStatus = responseStatus;
	}


	public String getResponseDesc() {
		return responseDesc;
	}


	public void setResponseDesc(String responseDesc) {
		this.responseDesc = responseDesc;
	}


	public RecepesMgmtResponseBean(String responseStatus, String responseDesc, List<Recepes> recepeList) {
		super();
		this.responseStatus = responseStatus;
		this.responseDesc = responseDesc;
		this.recepeList = recepeList;
	}


	@Override
	public String toString() {
		return "RecepesMgmtResponseBean [responseStatus=" + responseStatus + ", responseDesc=" + responseDesc
				+ ", recepeList=" + recepeList + "]";
	}
	
}
