--insert INTO recepe_details values(1001, 'This needs to be cooked well', 'N',datetime('now'),'CHICKEN CURRY', '100');
--insert INTO recepe_details values(1002, 'This needs to be cooked with care', 'Y',datetime('now'),'ALOO MUTTOR', '50');

--insert into recepe_ingredents values (1,'CHICKEN',1001);
--insert into recepe_ingredents values (2,'SALT',1001);
--insert into recepe_ingredents values (3,'MASALA',1001);


--insert into recepe_ingredents values (4,'OIL',1002);
--insert into recepe_ingredents values (5,'GOBI',1002);
--insert into recepe_ingredents values (6,'ALOO',1002);

--insert into recepe_ingredents values (7,'OIL MAIN',1002);
--insert into recepe_ingredents values (8,'MILK',1002);
--insert into recepe_ingredents values (9,'GREEN PEECE',1002);
insert into user_credentials values(1,'sharad','admin','sharad');
commit;